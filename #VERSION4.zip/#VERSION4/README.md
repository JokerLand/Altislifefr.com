Altis-Life
==========

Altis Life / Altis Life RPG is developed by Tonic / TAW_Tonic. This contains primarily the release contain and on-going development changes to the mission.
Altis Life RPG by Tonic is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License
http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US

Usage / Terms of agreement
* The branding of the mission is to stay ‘Altis Life RPG’. This means you cannot modify it to say something else. i.e Atlis Life by YOURCOMMUNITYNAME/TAG. Everything about the naming / branding is to be left untouched.
* Naturally all credit is to remain intact on all files. Author cannot be modified via Description.ext but can be extended in briefing.sqf
* All of my code is not to be used outside of the mission in another ‘Life’ like mission. It is to stay the Altis Life RPG Framework / my framework or you don’t use it and direct branding.
* Some of my code can be used outside of the mission / framework but permission is to be asked first, if no response is received then it is a automatic NO.
* Core configuration is allowed to be modified (i.e Prices and expansion of items / features).
* Features added by you to the mission are to stay to your modification in your server, distribution is not allowed without my permission, if you would like your feature to be added to the Altis Life RPG main distribution (by me) you can submit your changes and will be fully credited.
* This is not be used commercially and is to remain freeware, this includes requiring donations / payment to be able to ‘play’ in your server with this mission. Playability of it is to remain free and open.

The terms are subjected to be changed over time.

Disclaimer:
The vast majority of the code / framework has been written by me. Any additional code / content used is fully credited and owned by it’s author as well as linked to the authors content (Forums,Media,etc). The additional content used within the framework either has the expressed permission of the content creators permission or was automatically used under the GPU (General Purpose License) from public posting with no usage / TOA / Disclaimer, however they still own the rights to their content. If in any case that content is being used within this mission / framework that the content creator doesn’t wish for it to be used due to my strict TOA / Agreement all you need to do is ask for it to be removed and it will be honored.
